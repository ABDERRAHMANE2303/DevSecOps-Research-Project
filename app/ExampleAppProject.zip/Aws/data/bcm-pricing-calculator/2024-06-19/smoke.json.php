<?php
// This file was auto-generated from sdk-root/src/data/bcm-pricing-calculator/2024-06-19/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
