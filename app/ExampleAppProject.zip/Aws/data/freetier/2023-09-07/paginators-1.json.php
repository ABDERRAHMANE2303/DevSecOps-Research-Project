<?php
// This file was auto-generated from sdk-root/src/data/freetier/2023-09-07/paginators-1.json
return [ 'pagination' => [ 'GetFreeTierUsage' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'freeTierUsages', ], 'ListAccountActivities' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'activities', ], ],];
