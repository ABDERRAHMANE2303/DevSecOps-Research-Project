<?php
// This file was auto-generated from sdk-root/src/data/kendra-ranking/2022-10-19/paginators-1.json
return [ 'pagination' => [ 'ListRescoreExecutionPlans' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
