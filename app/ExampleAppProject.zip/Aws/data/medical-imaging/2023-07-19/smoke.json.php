<?php
// This file was auto-generated from sdk-root/src/data/medical-imaging/2023-07-19/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [],];
