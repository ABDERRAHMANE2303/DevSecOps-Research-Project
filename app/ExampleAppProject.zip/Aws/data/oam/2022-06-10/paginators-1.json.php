<?php
// This file was auto-generated from sdk-root/src/data/oam/2022-06-10/paginators-1.json
return [ 'pagination' => [ 'ListAttachedLinks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], 'ListLinks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], 'ListSinks' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Items', ], ],];
