<?php
// This file was auto-generated from sdk-root/src/data/resource-explorer-2/2022-07-28/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
