<?php
// This file was auto-generated from sdk-root/src/data/textract/2018-06-27/paginators-1.json
return [ 'pagination' => [ 'ListAdapterVersions' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'AdapterVersions', ], 'ListAdapters' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Adapters', ], ],];
