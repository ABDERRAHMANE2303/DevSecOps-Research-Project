<?php
// This file was auto-generated from sdk-root/src/data/appfabric/2023-05-19/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
