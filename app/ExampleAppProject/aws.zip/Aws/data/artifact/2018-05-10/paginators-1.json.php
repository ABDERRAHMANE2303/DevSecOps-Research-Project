<?php
// This file was auto-generated from sdk-root/src/data/artifact/2018-05-10/paginators-1.json
return [ 'pagination' => [ 'ListCustomerAgreements' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'customerAgreements', ], 'ListReports' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'reports', ], ],];
