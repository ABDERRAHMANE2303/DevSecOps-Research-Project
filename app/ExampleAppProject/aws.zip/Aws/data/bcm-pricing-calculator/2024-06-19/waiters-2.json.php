<?php
// This file was auto-generated from sdk-root/src/data/bcm-pricing-calculator/2024-06-19/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
