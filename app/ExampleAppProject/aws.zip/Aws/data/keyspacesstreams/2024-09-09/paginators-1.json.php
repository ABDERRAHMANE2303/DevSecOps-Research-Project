<?php
// This file was auto-generated from sdk-root/src/data/keyspacesstreams/2024-09-09/paginators-1.json
return [ 'pagination' => [ 'GetStream' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'shards', ], 'ListStreams' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'streams', ], ],];
