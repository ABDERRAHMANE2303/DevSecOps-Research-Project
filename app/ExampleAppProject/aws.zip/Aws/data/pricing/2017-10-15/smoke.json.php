<?php
// This file was auto-generated from sdk-root/src/data/pricing/2017-10-15/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
