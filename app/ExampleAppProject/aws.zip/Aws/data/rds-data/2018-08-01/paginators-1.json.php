<?php
// This file was auto-generated from sdk-root/src/data/rds-data/2018-08-01/paginators-1.json
return [ 'pagination' => [],];
